

import numpy as np
periodic_table = ('H', 'He', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Ne', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'Ar',
                  'K', 'Ca', 'Sc', 'Ti', 'V', 'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn', 'Ga', 'Ge', 'As', 'Se', 'Br',
                  'Kr', 'Rb', 'Sr', 'Y', 'Zr', 'Nb', 'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn', 'Sb', 'Te',
                  'I', 'Xe', 'Cs', 'Ba', 'La', 'Ce', 'Pr', 'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm',
                  'Yb', 'Lu', 'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir', 'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi', 'Po', 'At', 'Rn',
                  'Fr', 'Ra', 'Ac', 'Th', 'Pa', 'U', 'Np', 'Pu', 'Am', 'Cm', 'Bk', 'Cf', 'Es', 'Fm', 'Md', 'No', 'Lr',
                  'Rf', 'Db', 'Sg', 'Bh', 'Hs', 'Mt', 'Ds', 'Rg', 'Cn', 'Nh', 'Fl', 'Mc', 'Lv', 'Ts', 'Og', 'Uue')

# return numpy array


def elemPlace(n):
    if n == 1:
        return [1, 1]
    elif n == 2:
        return[18, 1]
    elif n <= 4:
        return[n-2, 2]
    elif n <= 12:
        return[n-10, 2]
    elif n <= 18:
        return[n, 3]
    elif n <= 36:
        return[n-18, 4]
    elif n <= 54:
        return[n-36, 5]
    elif n <= 71:
        return[n-54, 6]
    elif n <= 86:
        return[n-68, 7]
    elif n <= 103:
        return[n-86, 8]


import re
def toOneHotAndCount(s):
    count = 0
    conp = re.split(r"[0-9]{1,2}", s)
    num = re.split(r"[a-zA-z]{1,2}", s)
    conp.remove('')
    num.remove('')
    a = []
    for elemIndex in range(len(conp)):
        if conp[elemIndex] == '':
            continue
        elemNumber = periodic_table.index(conp[elemIndex])
        x, y = elemPlace(elemNumber)
        a.append(x)
        a.append(y)
        a.append(int(num[elemIndex]))
        count = count+int(num[elemIndex])

    for i in range(int(len(a)/3)):
        a[i*3+2] = a[i*3+2]/count
    return a, count


def toOneHot(s):
    a, _ = toOneHotAndCount(s)
    return a

# 元素种类个数，个数
def countElem(s):
    a, ac = toOneHotAndCount(s)
    return (len(a)/3, ac)


# input data，元素个数，种类个数
def selectDataByCount(data, ac, ec):
    c_data = []
    for d in data:
        ec_sub, ac_sub = countElem(d[2])
        if (ec_sub == ec or ec == 0) and (ac == ac_sub or ac == 0):
            c_data.append(d)
    return c_data


def top10(prop, labels, p=False, num=5):
    d = dict()
    res = []
    for i in range(prop.size):
        d[labels[i]] = prop[i]
    count = 0

    for i in sorted(d.items(), key=lambda kv: (kv[1], kv[0]), reverse=True):
        if count >= num:
            break
        if p:
            print(i)
        res.append(i[0])
        count = count+1
    return res


def read_datasets(path):
    data = []
    with open(path, 'r') as f:
        while True:
            line = f.readline()
            if not line:
                break
            else:
                try:
                    l = str(line).split()
                    typ = l[1].split('-')
                    arr = toOneHot(l[0])
                    data.append([arr, typ[1], typ[0]])
                except:
                    pass
    return data


def pre_process_data(data, proportion=0.1):
    import random
    trainning_data_index_list = random.sample(
        range(0, len(data)), int(len(data)*proportion))
    d_trainning = []
    d_test = []
    for i in range(0, len(data)):
        if i not in trainning_data_index_list:
            d_trainning.append(data[i])
        else:
            d_test.append(data[i])
    return d_trainning, d_test


def splitData(file):
    data = []
    with open(file, 'r') as f:
        while True:
            line = file.readline()
            if not line:
                break
            else:
                try:
                    data.append(line)
                except:
                    pass
    x, y, xt, yt = pre_process_data(data)


def trainning_svm(x_trainning, y_trainning, x_test, y_test):
    from sklearn.svm import SVC
    # clf = SVC(gamma='auto', probability=False, kernel="poly")
    clf = SVC(gamma='auto', probability=True, C=2)

    clf.fit(x_trainning, y_trainning)
    print("trainning complete, mean accuracy: "+str(clf.score(x_test, y_test)))
    return clf


def main(test="", ec=0, ac=0):
    if test:
        ec, ac = countElem(test)
    cacheData = True
    cacheClf = True
    import os
    import pickle
    from sklearn.externals import joblib

    if (cacheData or cacheClf) and not os.path.isdir("cache"):
        os.makedirs("cache")
    tile = str(ec) + "-" + str(ac)
    triFile = 'cache\data.pkl.'+tile
    testFile = 'cache\data_t.pkl'+tile
    if cacheData and os.path.isfile(triFile) and os.path.isfile(testFile):
        data_trainning = pickle.load(open(triFile, "rb"))
        data_test = pickle.load(open(testFile, "rb"))
    else:
        data = read_datasets("datasets\prototypes.list")

        data = selectDataByCount(data, ac, ec)
        if len(data) == 0:
            print("警告：空数据集")
            return
        print("数据集大小："+str(len(data)))
        data_trainning, data_test = pre_process_data(data)
        pickle.dump(data_trainning, open(triFile, "wb"))
        pickle.dump(data_test, open(testFile, "wb"))

    if cacheClf and os.path.isfile('cache\svm.pkl.'+tile):
        clf = joblib.load('cache\svm.pkl.'+tile)
    else:
        print("数据集大小："+str(len(data_test)+len(data_trainning)))
        clf = trainning_svm([data_trainning[i][0] for i in range(len(data_trainning))], [data_trainning[i][1] for i in range(len(data_trainning))], [
            data_test[i][0] for i in range(len(data_test))], [
            data_test[i][1] for i in range(len(data_test))])
        joblib.dump(clf, 'cache\svm.pkl.'+tile)
        if test:
            top10(clf.predict_proba([toOneHot(test)])[0], clf.classes_, p=True,)
    printCalculateAcc2(clf, data_test)
    printCalculateAcc2(clf, data_trainning)


def printCalculateAcc(clf, data_test):
    # calculate acc
    l_one = 0
    # l_two = 0
    res = clf.predict_proba([data_test[i][0] for i in range(len(data_test))])
    for i in range(len(res)):
        if top10(res[i], clf.classes_)[0] == data_test[i][1]:
            l_one = l_one+1
    print(l_one/len(data_test))


def printCalculateAcc2(clf, data_test):
    # calculate acc
    l_one = 0
    # l_two = 0
    res = clf.predict([data_test[i][0] for i in range(len(data_test))])
    for i in range(len(res)):
        if res[i] == data_test[i][1]:
            l_one = l_one+1
    print(l_one/len(data_test))


if __name__ == "__main__":
    for i in range(2, 5):
        for j in range(2, 11):
            if j < i:
                continue
            print("ec="+str(i)+" ac="+str(j))
            main(ec=i, ac=j)
    main(test="Ag1Ce1Sb2")
