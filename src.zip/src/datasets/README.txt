Example datasets:

prototypes.list - List of compositions and prototype names of 21587 stable compounds from the OQMD
small_set.txt   - DFT-computed properties of 612 randomly-selected compounds from the OQMD
simple-data.txt - 441 evaluations of f(x,y) = exp(-(x^2+y^2)/1000) * cos(3(x+y)/pi)
zirconia_sln_energies.txt - Dilute solution energy of 71 elememts, taken from: http://pubs.acs.org/doi/abs/10.1021/cm403727z

