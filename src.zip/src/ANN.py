
import re
import os
import time
import tensorflow as tf
import tensorflow.python.keras as keras
from keras import backend as K
from collections import OrderedDict, defaultdict
from keras.optimizers import RMSprop,SGD
from keras.layers import Dense, Activation,Dropout
from keras.models import Sequential,load_model
from keras.utils import np_utils
from keras.datasets import mnist
from tensorflow.python.keras.datasets import mnist

import numpy as np

#统一seed
SEED = 66478
np.random.seed(SEED)  

# %%
elements = ['H', 'Li', 'Be', 'B', 'C', 'N', 'O', 'F', 'Na', 'Mg', 'Al', 'Si', 'P', 'S', 'Cl', 'K', 'Ca', 'Sc', 'Ti', 'V',
            'Cr', 'Mn', 'Fe', 'Co', 'Ni', 'Cu', 'Zn', 'Ga', 'Ge', 'As', 'Se', 'Br', 'Kr', 'Rb', 'Sr', 'Y', 'Zr', 'Nb',
            'Mo', 'Tc', 'Ru', 'Rh', 'Pd', 'Ag', 'Cd', 'In', 'Sn', 'Sb', 'Te', 'I', 'Xe', 'Cs', 'Ba', 'La', 'Ce', 'Pr',
            'Nd', 'Pm', 'Sm', 'Eu', 'Gd', 'Tb', 'Dy', 'Ho', 'Er', 'Tm', 'Yb', 'Lu', 'Hf', 'Ta', 'W', 'Re', 'Os', 'Ir',
            'Pt', 'Au', 'Hg', 'Tl', 'Pb', 'Bi', 'Ac', 'Th', 'Pa', 'U', 'Np', 'Pu']


# %%
formulare = re.compile(r'([A-Z][a-z]*)([0-9|\.]*)')

#处理方程式
def parse_formula(formula):
    pairs = formulare.findall(formula)
    length = sum((len(p[0]) + len(p[1]) for p in pairs))
    assert length == len(formula)
    formula_dict = defaultdict(int)
    for el, sub in pairs:
        formula_dict[el] += float(sub) if sub else 1
    return formula_dict

# %%
#读取数据
def readdata(path):
    input_raw = []
    output_raw = []
    with open(path, 'r') as f:
        while True:
            line = f.readline()
            if not line:
                break
            else:
                try:
                    l = line.split()
                    if float(l[1]) > -3:
                        input_raw.append(l[0])
                        output_raw.append(float(l[1]))
                except:
                    print('error data:', line)

    #化学式格式化
    formulas = [parse_formula(x) for x in input_raw]
    # %%
    input = np.zeros(shape=(len(formulas), 86), dtype=np.float32)
    i = -1
    for formula in formulas:
        i += 1
        keys = formula.keys()
        values = formula.values()
        total = float(sum(values))
        for k in keys:
            input[i][elements.index(k)] = formula[k]/total
    output = np.asarray(output_raw)
    return input,output

# 训练用数据
input,output = readdata('trainning.data')
# 测试用数据
input_t,output_t = readdata('test_set.data')


#网络架构
model = Sequential([
    Dense(128, activation='relu'),
    Dense(128, activation='relu'),
    Dropout(0.2,seed = SEED),
    Dense(64, activation='relu'),
    Dense(64, activation='relu'),
    Dense(32, activation='relu'),
    Dense(1, activation='linear'),
])

# 优化器，RMSprop效果可以
rmsprop = RMSprop(lr=0.001, rho=0.9, epsilon=1e-08, decay=0.0)
adam = keras.optimizers.Adam()
sgd = SGD()

# compile
model.compile(optimizer=rmsprop,
              loss=tf.losses.absolute_difference,
              metrics=[])

saved_model = 'model.save'
if os.path.isfile(saved_model):
    print('Loading ------------')
    model = load_model(saved_model,compile = False)
    model.compile(optimizer=rmsprop,
              loss=tf.losses.absolute_difference,
              metrics=[])
else:

    print('Training ------------')
    model.fit(input, output, epochs=200,batch_size=256,validation_data=(input_t, output_t),verbose=1)
    model.save(saved_model)

predictions = model.predict(input_t)
size = input_t.shape[0]
print('Comparing')
errors = np.ndarray(shape=(size), dtype=np.float32)
mean_square_error = 0


for i in range(size):
    if (i  % 1000) == 0:
        print('{}\r'.format(i))
    errors[i] = abs(predictions[i]-output_t[i])
    #mean_square_error += abs(predictions[i]-output[i])
print(errors.sum()/size)

import matplotlib.pyplot as plt
plt.figure()
plt.subplot(1,2,1)
plt.scatter(predictions, output_t,label='class 1',s=1)
plt.grid(True)
plt.xlabel('ΔH ML (eV/atom)')
plt.ylabel('ΔH DFT (eV/atom)')

#计算误差
errors.sort()
plt.subplot(1,2,2)
plt.plot(errors,[x/size for x in range(size)])
plt.grid(True)
plt.xlabel('absolute error (eV/atom)')
plt.ylabel('CDF')
plt.show()
